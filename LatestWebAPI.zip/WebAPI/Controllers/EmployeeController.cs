﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using WebAPI.Models;


namespace WebAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public EmployeeController(IConfiguration configuration)
        {
            configuration = _configuration;

        }

        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
            select EmpId,EmpName,Dept from dbo.Employee";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand cmd = new SqlCommand(query, mycon))
                {
                    myReader = cmd.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    mycon.Close();

                }
            }
            return new JsonResult(table);
        }

        [HttpPost]
        public JsonResult Post(Employee emp)
        {
            string query = @"
           insert into dbo.Employee 
           (EmpName,Dept) 
            values 
            (
            '" + emp.EmpName + @"'
            ,'" + emp.Dept + @"'
            )
            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand cmd = new SqlCommand(query, mycon))
                {
                    myReader = cmd.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    mycon.Close();

                }
            }
            return new JsonResult("Added Successfully");
        }

        [HttpPut]
        public JsonResult Put(Employee emp)
        {
            string query = @"
           update dbo.Employee set
           EmpName ='" + emp.EmpName + @"'
            ,Dept ='" + emp.Dept + @"'
           where EmpId =" + emp.EmpId + @"
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand cmd = new SqlCommand(query, mycon))
                {
                    myReader = cmd.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    mycon.Close();

                }
            }
            return new JsonResult("Updated Successfully");
        }

        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
           delete from dbo.Employee
           where EmpId =" + id + @"
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand cmd = new SqlCommand(query, mycon))
                {
                    myReader = cmd.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    mycon.Close();

                }
            }
            return new JsonResult("Deleted Successfully");
        }

        [Route("api/Employee/GetAllDepartmentNames")]
        [HttpGet]
        public JsonResult GetAllDepartmentNames()
        {
            string query = @"
            select DeptName from dbo.Department";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            SqlDataReader myReader;
            using (SqlConnection mycon = new SqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (SqlCommand cmd = new SqlCommand(query, mycon))
                {
                    myReader = cmd.ExecuteReader();
                    table.Load(myReader);


                    myReader.Close();
                    mycon.Close();

                }
            }
            return new JsonResult(table);
        }
    }
}
