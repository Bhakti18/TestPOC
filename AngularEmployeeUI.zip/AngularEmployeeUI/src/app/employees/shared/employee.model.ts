export class Employee {
    EmployeeID : number;
    Name:string;
    Department:string;
}
