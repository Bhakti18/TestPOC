import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
readonly APIURL="http://localhost:54394/api/";

  constructor(private http:HttpClient) { }


  getDeptList():Observable<any[]>{
   return this.http.get<any>(this.APIURL + '/department');
  }

  getAllDepartmentNames():Observable<any[]>{
    return this.http.get<any[]>(this.APIURL + '/Employee/GetAllDepartmentNames');
   }

  addDepartment(val:any)
  {
    return this.http.post(this.APIURL + '/Department',val)
  }


  updateDepartment(val:any)
  {
    return this.http.put(this.APIURL + '/Department',val)
  }

  deleteDepartment(val:any)
  {
    return this.http.delete(this.APIURL + '/Department/'+val)
  }

  getEmpList():Observable<any[]>{
    return this.http.get<any>(this.APIURL + '/employee');
   }
 
  addEmployee(val:any)
   {
     return this.http.post(this.APIURL + '/Employee',val)
   }
 
 
   updateEmployee(val:any)
   {
     return this.http.put(this.APIURL + '/Employee',val)
   }
 
   deleteEmployee(val:any)
   {
     return this.http.delete(this.APIURL + '/Employee/'+val)
   }
}
