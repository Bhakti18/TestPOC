import { Component, OnInit,Input } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-dep',
  templateUrl: './add-edit-dep.component.html',
  styleUrls: ['./add-edit-dep.component.css']
})
export class AddEditDepComponent implements OnInit {

  constructor(private service:SharedService) { }

  @Input() dep:any;
  DeptId :string;
  DeptName : string;

  ngOnInit(): void {
    this.DeptId=this.dep.DeptId;
    this.DeptName=this.dep.DeptName;
  }
  addDepartment()
  {
    var val={ 
      DeptId: this.dep.DeptId,
      DeptName: this.dep.DeptName
           };
    this.service.addDepartment(val).subscribe(res=>{
      alert(res.toString());
      });
  }

  updateDepartment(){
    var val={ 
      DeptId: this.dep.DeptId,
      DeptName: this.dep.DeptName
           };
    this.service.updateDepartment(val).subscribe(res=>{
      alert(res.toString());
      });
  }
}
