import { Component, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-show-dep',
  templateUrl: './show-dep.component.html',
  styleUrls: ['./show-dep.component.css']
})
export class ShowDepComponent implements OnInit {

  constructor(private service:SharedService) {    
  }

  DepartmentList:any=[];
  Modaltitle :string;
  ActivateAddEditDepComp : boolean =false;
  dep:any;



  ngOnInit(): void {
    this.refreshDeptList();
  }
addClick(){
  this.dep={
    DeptId:0,
    DeptName :""
  }
  this.Modaltitle="Add Department";
  this.ActivateAddEditDepComp=true;
  }

  closeClick(){
    this.ActivateAddEditDepComp=false;
    this.refreshDeptList();
  }

  editClick(item){
    this.dep=item;
    this.Modaltitle="Edit Department";
    this.ActivateAddEditDepComp=true;
    }

    deleteClick(item){
if(confirm('Are you sure?')){
this.service.deleteDepartment(item.DeptId).subscribe(data=>{
alert(data.toString());
this.refreshDeptList();
});
}

    }

refreshDeptList()
{
  this.service.getDeptList().subscribe(data=>{
this.DepartmentList=data;
  });
}
}
