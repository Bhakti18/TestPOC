import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit,Input } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-emp',
  templateUrl: './add-edit-emp.component.html',
  styleUrls: ['./add-edit-emp.component.css']
})
export class AddEditEmpComponent implements OnInit {

  constructor(private service:SharedService) { }

  @Input() emp:any;
  EmpId :string;
  EmpName :string;
  DeptName : string;

  DepartmentsList:any=[];

  ngOnInit(): void {
    this.loadDepartmentList();
    
  }

  loadDepartmentList(){
    this.service.getAllDepartmentNames().subscribe(data=>{
      this.DepartmentsList=data;

      this.EmpId=this.emp.EmpId;
    this.EmpName=this.emp.EmpName;
    this.DeptName=this.emp.DeptName;
    })
  }
  addEmployee()
  {
    var val={ 
      EmpId: this.emp.EmpId,
      EmpName: this.emp.EmpName,
      DeptName: this.emp.DeptName
           };
    this.service.addEmployee(val).subscribe(res=>{
      alert(res.toString());
      });
  }

  updateEmployee(){
    var val={ 
      EmpId: this.emp.EmpId,
      EmpName: this.emp.EmpName,
      DeptName: this.emp.DeptName
           };
    this.service.updateEmployee(val).subscribe(res=>{
      alert(res.toString());
      });
  }
}
